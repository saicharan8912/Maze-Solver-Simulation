#include <iostream>
#include <cstdlib>
#include "../include/mouse/mouse.h"
#include "../include/api/api.h"
#include "../include/log/log.h"


int main(int argc, char *argv[])
{
	rwa2::Mouse mouse;
	bool check{false};
	std::pair<int,int> goal{7,7};
	std::pair<int,int> current{0,0};
	mouse.display_walls();					
	while (!check)                          // checks if the mouse reached the goal.
	{
		check=mouse.search_maze(goal);    	// Check is assigned TRUE when goal is reached breaking the while loop.

	}
	mouse.final_path();                    //Displays the final path taken by the mouse from start to goal.

	
}