#include "../include/log/log.h"
                                                            
void log(const std::string text) {
    std::cerr << text << std::endl;
}

void log(const int text) {
    std::cerr << text << std::endl;
}

void log(const char text[]) {
    std::cerr << "Sucessful" << std::endl;
}

void log(bool response) {
    if (response)
    {
        std::cerr << "True" << std::endl;
    }else
    {
        std::cerr << " False " << std::endl;
    }
    
    
}