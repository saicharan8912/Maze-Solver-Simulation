#include "../include/mouse/mouse.h"
#include "../include/api/api.h"
#include "../include/util/util.h"
#include "../include/log/log.h"
#include "../include/func/func.h"
#include <string>
#include <iostream>
#include <cstdlib>
#include<unistd.h>
#include <algorithm>
void rwa2::Mouse::display_walls()                                                
{
    for (int x = 0; x < m_maze_width; x += 1)
    {
        for (int y = 0; y < m_maze_height; y += 1)
        {
            if (m_maze.at(x).at(y).is_wall(direction::NORTH))
            {
                //display North wall in the simulator
                API::setWall(x, y, 'n');
            }

            if (m_maze.at(x).at(y).is_wall(direction::EAST))
            {
                //display East wall in the simulator
                API::setWall(x, y, 'e');
            }

            if (m_maze.at(x).at(y).is_wall(direction::SOUTH))
            {
                //display South wall in the simulator
                API::setWall(x, y, 's');
            }

            if (m_maze.at(x).at(y).is_wall(direction::WEST))
            {
                //display West wall in the simulator
                API::setWall(x, y, 'w');
            }
            //display the number of walls surrounding the current node
            API::setText(x, y, std::to_string(m_maze.at(x).at(y).compute_number_of_walls()));
        }
    }
}


void rwa2::Mouse::move_forward(int direction)
{

    API::moveForward();     
    switch (direction)                   // Increments or Decrements the coordinates with respect to the direction of the mouse.
    {
    case 0:                    
    {
        m_y += 1;
        break;
    }
    case 1:
    {
        m_x += 1;
        break;
    }
    case 2:
    {
        m_y -= 1;
        break;
    }
    case 3:
    {
        m_x -= 1;
        break;
    }

    default:
        break;
    }
    std::pair<int, int> temp{m_x, m_y};
    API::setColor(m_x, m_y, 'G');                                   // Sets the colour to Green.
    check_node(m_x, m_y, direction);                                // Updates all walls of the node it is present in.
}

void rwa2::Mouse::turn_right()                                      // Conditions to turn the mouse right.     
{
    API::turnRight();
    if (m_direction < 3)
    {
        m_direction += 1;
    }
    else
    {
        m_direction = 0;
    }
    check_node(m_x, m_y, m_direction);
}

void rwa2::Mouse::turn_left()                                        // Conditions to turn the mouse left.
{
    API::turnLeft();
    if (m_direction > 0)
    {
        m_direction -= 1;
    }
    else
    {
        m_direction = 3;
    }
    check_node(m_x, m_y, m_direction);
}

void rwa2::Mouse::check_node(int x, int y, int direction)
{

    switch (direction)                                                     // Checks for walls in all directions based if it is facing North East South West.
    {
    case 0:
    {
        if (API::wallFront())
        {
            m_maze.at(x).at(y).set_wall(0, true);
        }
        if (API::wallRight())
        {
            m_maze.at(x).at(y).set_wall(1, true);
        }
        if (API::wallLeft())
        {
            m_maze.at(x).at(y).set_wall(3, true);
        }
        break;
    }
    case 1:
    {
        if (API::wallFront())
        {
            m_maze.at(x).at(y).set_wall(1, true);
        }
        if (API::wallRight())
        {
            m_maze.at(x).at(y).set_wall(2, true);
        }
        if (API::wallLeft())
        {
            m_maze.at(x).at(y).set_wall(0, true);
        }
        break;
    }
    case 2:
    {
        if (API::wallFront())
        {
            m_maze.at(x).at(y).set_wall(2, true);
        }
        if (API::wallRight())
        {
            m_maze.at(x).at(y).set_wall(3, true);
        }
        if (API::wallLeft())
        {

            m_maze.at(x).at(y).set_wall(1, true);
        }
        break;
    }
    case 3:
    {
        if (API::wallFront())
        {
            m_maze.at(x).at(y).set_wall(3, true);
        }
        if (API::wallRight())
        {

            m_maze.at(x).at(y).set_wall(0, true);
        }
        if (API::wallLeft())
        {
            m_maze.at(x).at(y).set_wall(2, true);
        }
        break;
    }

    default:
        break;
    }

    display_walls();                                                         // Displays the walls around the node.
}

void rwa2::Mouse::paint_black()                                             // Colours the whole maze in black.
{


        std::pair<int, int> paint{navstack.top()};
        
        for (int x = 0; x < m_maze_width; x += 1)
        {
            for (int y = 0; y < m_maze_height; y += 1)
            {
                
                    API::setColor(x, y, 'k');                                // Sets black colour
                
            }
        }

        unsigned int microsecond = 100000;
        usleep(1 * microsecond);

        while (!navstack.empty())
        {
            API::setColor(navstack.top().first,navstack.top().second,'C');        // Displays the DFS path in Cyan.
            navstack.pop();
            unsigned int microsecond = 10;
            usleep(1 * microsecond);

        }
        

}

void rwa2::Mouse::final_path()                                    // Generates the final path taken by the mouse from start to goal node.
{
    for (int x = 0; x < m_maze_width; x += 1)
        {
            for (int y = 0; y < m_maze_height; y += 1)
            {
                
                    API::setColor(x, y, 'k');
                
            }
        }

    
    while (!v.empty())
    {
        std::pair<int, int> temp{v.back().first,v.back().second};
        API::setColor(temp.first, temp.second, 'B');
        API::setText(temp.first, temp.second,"Vis");

        v.pop_back();
    }
     std::pair<int, int> temp{s.top().first, s.top().second};
        API::setColor(temp.first, temp.second, 'G');
        API::setText(temp.first, temp.second,"Goal");

        s.pop();

    while (!s.empty())
    {
        std::pair<int, int> temp{s.top().first, s.top().second};
        API::setColor(temp.first, temp.second, 'G');
        API::setText(temp.first, temp.second,"Path");

        s.pop();
    }
            API::setColor(0,0, 'G');
            API::setText(0,0,"Start");
}

void rwa2::Mouse::empty_stack(std::stack<std::pair<int, int>> stk)                           // Empty's the stack.
{
    while (!stk.empty())
    {
        m_maze.at(stk.top().first).at(stk.top().second).set_visited(false);

        stk.pop();
    }
}

void rwa2::Mouse::empty_visted_generated()                                                 // Empty the visited nodes.
{
  
    nav_visited.clear();
}

void rwa2::Mouse::generate_path(std::pair<int, int> n, std::pair<int, int> g)                // Genrates the path to the goal node.
{
    
    bool check = {true};
    
    if (((n.first >= 0) && (n.second >= 0)) && ((n.first < 16) && (n.second < 16))) 
    {
        while (check)
        {

            if ((n.first == g.first) && (n.second == g.second))                             // Cheks if the Goal is reached.
            {

                std::cerr << "Goal Reached Through DFS" << std::endl;
                

                paint_black();
                check = false;
                empty_stack(navstack);
                empty_visted_generated();
            }
            else
            {
                
                if (!m_maze.at(n.first).at(n.second).is_wall(0) && (check_visted_for_generated(n.first, n.second + 1, nav_visited)))
                {
                    //checks North
                    m_maze.at(n.first).at(n.second).set_visited(true);
                    n.second += 1;
                    API::setColor(n.first, n.second, 'w');
                    navstack.push({n.first, n.second});
                    nav_visited.push_back({n.first, n.second});
                   
                }
                else
                {
                    if ((!m_maze.at(n.first).at(n.second).is_wall(1)) && (check_visted_for_generated(n.first + 1, n.second, nav_visited)))
                    {
                        //checks east
                        m_maze.at(n.first).at(n.second).set_visited(true);
                        n.first += 1;
                        API::setColor(n.first, n.second, 'w');
                        navstack.push({n.first, n.second});
                        nav_visited.push_back({n.first, n.second});

                       
                    }
                    else
                    {

                        if ((!m_maze.at(n.first).at(n.second).is_wall(2)) && (check_visted_for_generated(n.first, n.second - 1, nav_visited)))
                        {
                            //checks south
                            m_maze.at(n.first).at(n.second).set_visited(true);
                            n.second -= 1;
                            API::setColor(n.first, n.second, 'w');
                            navstack.push({n.first, n.second});
                            nav_visited.push_back({n.first, n.second});
                        }
                        else
                        {

                            if (!m_maze.at(n.first).at(n.second).is_wall(3) && (check_visted_for_generated(n.first - 1, n.second, nav_visited)))
                            {
                                //checks west
                                m_maze.at(n.first).at(n.second).set_visited(true);
                                n.first -= 1;
                                API::setColor(n.first, n.second, 'w');
                                
                                navstack.push({n.first, n.second});
                                nav_visited.push_back({n.first, n.second});
                            }
                            else
                            {

                                std::pair<int, int> current_pos{navstack.top().first, navstack.top().second};
                                
                                navstack.pop();
                                

                                std::pair<int, int> previous_pos{navstack.top().first, navstack.top().second};
                                int x_shift{0};
                                int y_shift{0};
                                x_shift = previous_pos.first - current_pos.first;
                                y_shift = previous_pos.second - current_pos.second;
                                if (x_shift == 0 && y_shift == -1)
                                {
                                    n.second -= 1;
                                }
                                if (x_shift == 0 && y_shift == 1)
                                {
                                    n.second += 1;
                                }
                                if (x_shift == -1 && y_shift == 0)
                                {
                                    n.first -= 1;
                                }
                                if (x_shift == 1 && y_shift == 0)
                                {
                                    n.first += 1;
                                }
                                
                            }
                        }
                    }
                }
            }
        }
    }
}

bool rwa2::Mouse::search_maze(std::pair<int, int> g)
{
    std::pair<int, int> current{0, 0};
    current.first = m_x;
    current.second = m_y;
    check_node(m_x, m_y, m_direction);
    check_node(m_x, m_y, m_direction);
    API::setColor(g.first,g.second,'Y');                              // Sets colour of goal node.

    if (m_x == g.first && m_y == g.second)                           // Checks if the goal is reached.
    {
        std::cerr << "Goal Reached By Mouse" << std::endl;                    
        API::setColor(m_x, m_y, 'Y');
        return true;
    }
    else
    {

        switch (m_direction)                                                      // Checks the walls around the node and also checks the visited nodes in order to back-track.
        {
        case 0:
        {
            if ((!API::wallFront()) && (!search_visited(m_x, m_y + 1, v)))
            {
                move_forward(m_direction);
                s.push({m_x, m_y});
                API::setColor(m_x, m_y, 'G');
                v.push_back(m_maze.at(m_x).at(m_y).get_cords());
            }
            else
            {
                if (!API::wallRight() && (!search_visited(m_x + 1, m_y, v)))
                {
                    turn_right();
                    move_forward(m_direction);
                    s.push({m_x, m_y});
                    API::setColor(m_x, m_y, 'G');

                    v.push_back(m_maze.at(m_x).at(m_y).get_cords());
                }
                else
                {
                    turn_right();
                    turn_right();
                    if (!API::wallFront() && (!search_visited(m_x, m_y - 1, v)))
                    {
                        move_forward(m_direction);
                        s.push({m_x, m_y});
                        API::setColor(m_x, m_y, 'G');

                        v.push_back(m_maze.at(m_x).at(m_y).get_cords());
                    }
                    else
                    {
                        turn_right();

                        if (!API::wallFront() && (!search_visited(m_x - 1, m_y, v)))
                        {
                            move_forward(m_direction);
                            s.push({m_x, m_y});
                            API::setColor(m_x, m_y, 'G');

                            v.push_back(m_maze.at(m_x).at(m_y).get_cords());
                        }
                        else
                        {

                            std::pair<int, int> temp{s.top().first, s.top().second};
                            s.pop();
                            API::setColor(m_x, m_y, 'B');

                            std::pair<int, int> temp2{s.top().first, s.top().second};
                            int x_shift{0};
                            int y_shift{0};
                            x_shift = temp2.first - temp.first;
                            y_shift = temp2.second - temp.second;
                            if (x_shift == 0 && y_shift == -1)
                            {
                                turn_left();
                                move_forward(m_direction);
                            }
                            if (x_shift == 0 && y_shift == 1)
                            {
                                turn_right();
                                move_forward(m_direction);
                            }
                            if (x_shift == -1 && y_shift == 0)
                            {
                                move_forward(m_direction);
                            }
                            if (x_shift == 1 && y_shift == 0)
                            {
                                turn_right();
                                turn_right();
                                move_forward(m_direction);
                            }
                        }
                    }
                }
            }

            break;
        }
        case 1:                                                          // The mouse faces North before checking the walls and visited nodes.
        {
            turn_left();
            break;
        }
        case 2:
        {
            turn_left();
            turn_left();
            break;
        }
        case 3:
        {
            turn_right();
            break;
        }

        default:
            break;
        }
    }
        generate_path(current, g);                                       // Generates the DFS path shown in WHITE each time the mouse moves.

    return false;
}