#include "../include/func/func.h"  
#include "../include/mouse/mouse.h"
#include <vector>
#include <algorithm>
#include <iostream>
#include <stack>

bool search_visited(int x, int y ,std::vector<std::pair<int,int>>& visited){               // mouse checks if the next node is visited or not.
    std::pair<int,int> temp{x,y};

    if (std::find(visited.begin(), visited.end(), temp) != visited.end()&&((x>=0&&y>=0)&&(x<16&&y<16)))
    {
        return true;
    }else
    {   
        return false;
    }
}

bool check_visted_for_generated(int x, int y, std::vector<std::pair<int,int>> visited){             // DFS checks if the next node is visited or not. 
std::pair<int,int> temp{x,y};

    if (std::find(visited.begin(), visited.end(), temp) != visited.end()&&((x>=0&&y>=0)&&(x<16&&y<16)))
    {
        return false;
    }else
    {   
        return true;
    }
}

