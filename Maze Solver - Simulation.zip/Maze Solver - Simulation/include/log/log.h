/**
 * @file log.h
 * @author Sri Sai Charan Vellisetti (svellise@umd.edu)
 * @author Mukundhan Rajendiran (mrajendi@umd.edu)
 * @author Ashutosh Reddy (atimyala@umd.edu)
 * @brief 
 * @version 0.1
 * @date 2021-11-15
 * 
 * @copyright Copyright (c) 2021
 * 
 */
#ifndef LOG_H
#define LOG_H

#include <string>
#include <iostream>

/**
 * @brief A function to test various variable in the code during development
 * 
 * @param text 
 */
void log(const std::string text);

void log(const int text);

void log(bool response);

void log(const char text[]);

#endif