/**
 * @file node.h
 * @author Sai Charan (svellise@umd.edu)
 * @author Mukundhan Rajendiran (mrajendi@umd.edu)
 * @author Ashutosh Reddy (atimyala@umd.edu)
 * @brief This file contains a class to represent a node in a maze.
 * @version 0.1
 * @date 2021-10-24
 * 
 * @copyright Copyright (c) 2021
 * 
 */


#ifndef NODE_H
#define NODE_H

#include <array>

namespace rwa2 {
    /**
     * @brief Class to represent a node (cell) in a maze.
     *
     *A node is just a space delimited by 4 walls
     *
     */
    class Node
    {
    public:
        Node() {
            for (int i = 0; i < 4; i += 1) {
                m_walls[i] = false;
            }
        }
        /**
         * @brief Sets the wall of a node.
         *
         * @param direction NORTH, EAST, SOUTH, or WEST
         * @param is_wall true if there is a wall, otherwise false
         */
        void set_wall(int direction, bool is_wall);
        /**
         * @brief Returns whether or not there is a wall around a node.
         *
         * @param direction Direction to set for wall (NORTH, EAST, SOUTH, or WEST)
         * @return true There is a wall in the given direction in the cell
         * @return false There is no wall in the given direction in the cell
         */
        bool is_wall(int direction) const;
        /**
         * @brief Computes the number of walls surrounding a node.
         * 
         * @return int Number of walls surrounding a node.
         */
        int compute_number_of_walls() const;

        std::pair<int,int> get_cords();

        /**
         * @brief Sets the coordinates of the nodes.
         * 
         * @param x 
         * @param y 
         */

        void set_cords(int x,int y);

        /**
         * @brief Sets the visited nodes in the maze.
         * 
         * @param set 
         */

        void set_visited(bool set);

        /**
         * @brief returns if the nodes are visited.
         * 
         * @return true 
         * @return false 
         */

        bool get_visited();

    private:
        std::array<bool, 4> m_walls; //all four walls in a cell
        std::pair<int , int> cords; //Stores the cordinates of each node 
        bool visited{false};

    };
}
#endif
