/**
 * @file func.h
 * @author Sri Sai Charan Vellisetti (svellise@umd.edu)
 * @author Mukundhan Rajendiran (mrajendi@umd.edu)
 * @author Ashutosh Reddy (atimyala@umd.edu)
 * @brief This file consists of two functions of mouse and DFS checking if the nodes are visited along the travelled path to the goal.
 * @version 0.1
 * @date 2021-11-15
 * 
 * @copyright Copyright (c) 2021
 * 
 */

#ifndef FUNC_H
#define FUNC_H

#include <stack>
#include <iostream>
#include <vector>
/**
 * @brief Using a Boolean function, the mouse checks if the next node in the path is visited or not.  
 * @param x 
 * @param y 
 * @param visited 
 * @return true 
 * @return false 
 */
bool search_visited(int x, int y,std::vector<std::pair<int,int>>& visited);

/**
 * @brief Depth First Search algorithm checks whether the next node is visited or not in the generated path to the goal.
 * @param x 
 * @param y 
 * @param visited 
 * @return true 
 * @return false 
 */

bool check_visted_for_generated(int x, int y, std::vector<std::pair<int,int>> visited);
#endif