var searchData=
[
  ['turn_5fleft',['turn_left',['../classrwa2_1_1_mouse.html#a5748e94e740432c334d15364fb476919',1,'rwa2::Mouse']]],
  ['turn_5fright',['turn_right',['../classrwa2_1_1_mouse.html#ac929127d86fc4a41d1e216968b1dae20',1,'rwa2::Mouse']]]
];
